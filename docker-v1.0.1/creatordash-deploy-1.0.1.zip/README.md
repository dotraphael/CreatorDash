# CreatorDash Web - Docker deployment

This bundle deploys CreatorDash Web as a Linux container. It pairs with the
`creatordash-web-<version>.tar.gz` image tarball shipped alongside it.

## What's in this bundle

- `docker-compose.yml` - the stack definition (single web service)
- `.env.example` - template for the configuration values
- `README.md` - this file

The image itself ships separately as `creatordash-web-<version>.tar.gz`, and
`sha256sum-container.txt` carries the checksums for integrity verification.

## Prerequisites

- Docker 24.0+ with Docker Compose v2 (`docker compose version` to check)
- ~2 GB of disk space for the image and data (the image bundles ffmpeg and the
  Claude Code CLI)
- For the MariaDB provider: an external MariaDB 10.5+ / MySQL 8+ reachable from
  the Docker host. The default SQLite provider needs nothing external.
- For the Claude CLI AI provider (optional): an Anthropic API key or a Claude
  subscription. The `claude` binary itself is baked into the image.

## Verify the download

Check the two artefacts against the published checksums before loading anything:

    # Linux / macOS / Git Bash (run from the folder holding all three files):
    sha256sum -c sha256sum-container.txt

    # Windows PowerShell:
    Get-Content sha256sum-container.txt | ForEach-Object {
        $hash, $name = $_ -split '\s+', 2
        $actual = (Get-FileHash $name.Trim() -Algorithm SHA256).Hash.ToLower()
        "{0}  {1}" -f ($(if ($actual -eq $hash) {'OK  '} else {'FAIL'}), $name.Trim())
    }

## Setup

1. **Load the image:**

        docker load -i creatordash-web-<version>.tar.gz

   Verify it is present (note the tag - you set it as `CREATORDASH_VERSION` below):

        docker images creatordash/web

2. **Unzip this deploy bundle and change into it:**

        # Linux / macOS / Git Bash:
        unzip creatordash-deploy-<version>.zip -d creatordash-deploy-<version>

        # Windows PowerShell:
        Expand-Archive -Path .\creatordash-deploy-<version>.zip -DestinationPath .\creatordash-deploy-<version>

        cd creatordash-deploy-<version>

3. **Copy the env template and fill it in:**

        cp .env.example .env      # PowerShell: Copy-Item .env.example .env

   Required fields: `CREATORDASH_VERSION` (the tag you loaded in step 1, e.g.
   `1.0.0`), `Encryption__Key`, and `InitialUser__Password`. The default
   `Database__Provider=Sqlite` needs no database server; set it to `MariaDb` and
   fill `ConnectionStrings__MariaDb` to use an external server instead.

   Generate the encryption key before you start:

        # Linux / macOS / Git Bash:
        openssl rand -base64 32

        # Windows PowerShell:
        $b=[byte[]]::new(32);[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b);[Convert]::ToBase64String($b)

   **Back up `Encryption__Key` immediately.** If it is lost, every encrypted
   secret (tenant AI keys, OAuth client secrets) becomes permanently
   unrecoverable.

   Values in `.env` are passed to the container verbatim - write passwords and
   connection strings literally, including any `$`, `!`, or quote characters.

4. **Start the stack:**

        docker compose up -d

5. **Tail the logs until startup completes:**

        docker compose logs -f web

   On first run, EF Core migrations create the schema and the initial admin user
   is seeded.

6. **Open the app:**

   Browse to `http://<host>:8080` (or whatever you set `HOST_PORT` to). Log in
   with `InitialUser__UserName` / `InitialUser__Password`, then change the
   password.

7. **Stop the stack:**

        docker compose down

   Data survives in the named volumes (`creatordash-data`, `creatordash-keys`,
   `creatordash-logs`). `docker compose down -v` also deletes those volumes
   (database, keys, logs) - do not use it unless you mean to wipe everything.

## Configuration reference

Every key below is an environment variable in `.env`. It overrides the matching
`appsettings.json` key via the ASP.NET Core `__` -> `:` convention (so
`Database__Provider` sets `Database:Provider`).

### Required

| Variable | Purpose |
|---|---|
| `CREATORDASH_VERSION` | Image tag to run - must match the loaded tarball. |
| `Encryption__Key` | Base64 256-bit AES key encrypting secrets at rest. Back it up. |
| `InitialUser__Password` | Password for the seeded admin (`InitialUser__UserName`). |

### Database

| Variable | Default | Purpose |
|---|---|---|
| `Database__Provider` | `Sqlite` | `Sqlite` (single container) or `MariaDb` (external server). |
| `ConnectionStrings__Sqlite` | `Data Source=/data/creatordash.db` | SQLite file path (a **container** path, on the `/data` mount). |
| `ConnectionStrings__MariaDb` | _(unset)_ | MariaDB/MySQL connection string. Required when provider is `MariaDb`. |
| `Database__ServerVersion` | `11.4.0-mariadb` | Pins the SQL dialect, skipping startup auto-detect (MariaDb only). |
| `Database__Sqlite__BusyTimeoutSeconds` | `30` | Wait for the SQLite write lock before failing (SQLite only). |

### Identity / secrets

| Variable | Default | Purpose |
|---|---|---|
| `InitialUser__UserName` | `admin` | Login name of the seeded administrator. |
| `InitialUser__Email` | `admin@localhost` | Email of the seeded administrator. |
| `DataProtection__KeysPath` | `/keys` | Data Protection key ring (container path, on the `/keys` mount). Must persist or all sessions drop on restart. |

### Logging

Logs are written to `FileLogging__Path` (default `/logs`, on the `/logs` mount).
Each file rolls daily.

| Variable | Default | Purpose |
|---|---|---|
| `FileLogging__Path` | `/logs` | Directory for rolling log files (container path). |
| `FileLogging__MaxLogSizeMb` | `25` | Max size of one log file before it rolls. |
| `FileLogging__MaxHistoryFiles` | `31` | Max rolled files to retain. |
| `Serilog__MinimumLevel__Default` | `Information` | Global log level. Override per namespace with `Serilog__MinimumLevel__Override__<Namespace>`. |

### Networking / misc

| Variable | Default | Purpose |
|---|---|---|
| `HOST_PORT` | `8080` | Host port mapped to the container's `8080`. |
| `Jobs__RunInWebHost` | `true` | Run scheduled jobs in-process. Leave on for a single instance. |
| `Ffmpeg__BinaryFolder` | _(empty)_ | Override the ffmpeg folder. Empty uses the ffmpeg baked into the image. |

### AI - Claude CLI provider

The Claude Code CLI (`claude`) is baked into the image, so choosing the "Claude
CLI" AI provider in the app works out of the box **except for credentials** - a
`claude` you installed on the Docker host is not visible to the container.
Authenticate one of two ways:

- **API key (headless, recommended for a server):** set `ANTHROPIC_API_KEY`.
- **Subscription (Pro/Max):** run `docker compose exec web claude setup-token`
  once so the token is written to the CLI config dir, or copy your host
  `~/.claude/.credentials.json` into that dir. The config dir is
  `CLAUDE_CONFIG_DIR=/data/claude`, persisted on the `/data` mount.

| Variable | Default | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | _(unset)_ | Anthropic API key. Set for headless Claude CLI auth. |
| `CLAUDE_CONFIG_DIR` | `/data/claude` | CLI config/credentials dir (set in the image; persists on `/data`). |
| `Ai__ClaudeCli__Executable` | `claude` | CLI binary name/path. Baked in as `/usr/bin/claude`. |
| `Ai__ClaudeCli__TimeoutSeconds` | `120` | Hard cap on one CLI invocation. |
| `Ai__ClaudeCli__ExtraArguments` | _(unset)_ | Extra flags passed before the prompt. |

The CLI is added at build time via the `INSTALL_CLAUDE_CLI` build arg (default
`true`). Images built with `INSTALL_CLAUDE_CLI=false` omit Node.js and `claude`;
the Claude CLI provider is then unavailable, but HTTP AI providers still work.

## Persistent data

Stateful files live on three named volumes, each on its own container mount:

| Volume | Mount | Holds |
|---|---|---|
| `creatordash-data` | `/data` | SQLite database + Claude CLI config (`/data/claude`) |
| `creatordash-keys` | `/keys` | Data Protection key ring |
| `creatordash-logs` | `/logs` | Rolling log files |

The volumes are initialised from the image and owned by the container's non-root
user, so no host-side `chown` is needed. Back them up to back up the deployment:

    for v in creatordash-data creatordash-keys creatordash-logs; do
        docker run --rm -v "$v":/v -v "$PWD":/backup alpine \
            tar czf "/backup/$v-backup.tar.gz" -C /v .
    done

### Using host folders instead of named volumes (bind-mounts)

To store data in host folders you can browse and back up directly, set the
`DATA_PATH`, `KEYS_PATH`, and `LOGS_PATH` variables in `.env` to absolute host
paths. Unset, they fall back to the named volumes above.

    DATA_PATH=/usr_docker/creatordash/data
    KEYS_PATH=/usr_docker/creatordash/keys
    LOGS_PATH=/usr_docker/creatordash/logs

**Important:** these are the only variables that take **host** paths. The app's
own path settings (`ConnectionStrings__Sqlite`, `DataProtection__KeysPath`,
`FileLogging__Path`) are always **container** paths - `/data/creatordash.db`,
`/keys`, `/logs` - never the host paths. Point the app at a host path and it
fails with `unable to open database file`, because that path does not exist
inside the container.

Create the host folders first and make them writable by the container's non-root
user before starting:

    mkdir -p /usr_docker/creatordash/{data,keys,logs}
    chmod 777 /usr_docker/creatordash/{data,keys,logs}

## Upgrading to a newer version

1. Load the new image: `docker load -i creatordash-web-<newversion>.tar.gz`
2. Set `CREATORDASH_VERSION` in `.env` to the new tag.
3. `docker compose up -d`

Database migrations run automatically on startup. Roll back by re-setting the
old tag and running `docker compose up -d` again.

## Troubleshooting

**`Encryption:Key is not configured` on startup** - `Encryption__Key` in `.env`
is blank. Generate one (`openssl rand -base64 32`) and restart. If you changed a
previously-set key, secrets encrypted under the old key are unrecoverable;
restore the original from your backup.

**Can't connect to the database (MariaDb)** - check `ConnectionStrings__MariaDb`.
If it works from the host but not the container, confirm the DB host is reachable
from inside: `docker compose exec web getent hosts <dbhost>`. Passwords with `$`
or `!` must be written literally in `.env` (no escaping).

**Logged out on every restart** - `DataProtection__KeysPath` is not persisting.
Confirm the `/keys` mount is present and not being recreated.

**`unable to open database file` (SQLite Error 14) on startup** - the SQLite,
keys, or logs path points at a location the container can't write. These settings
are **container** paths (`/data/creatordash.db`, `/keys`, `/logs`), not host
paths. If you bind-mount host folders, put the host path in `DATA_PATH` /
`KEYS_PATH` / `LOGS_PATH` only, and make those folders writable (`chmod 777`).

**`Claude CLI executable 'claude' could not be started`** - either the image was
built with `INSTALL_CLAUDE_CLI=false` (rebuild with it `true`), or the CLI has no
credentials. Set `ANTHROPIC_API_KEY`, or run `docker compose exec web claude
setup-token` for subscription auth. Verify the binary is present:
`docker compose exec web claude --version`.

**Container keeps restarting** - `docker compose logs web`. Common causes: blank
required secret, unreachable MariaDB, or a bad connection string.
